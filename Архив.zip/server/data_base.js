const { pin_status, get_tables, get_user_location } = require("../front/global_values")
const connect_networks = require("./connect_global_data")



module.exports.check_network = function (pin) {
   connect_networks.query('SELECT * FROM all_networks', function (err, results) {
      if (err) { console.log(err) }
      else {
         results.forEach(obj => {
            if (obj.pin == pin) { localStorage.setItem('data_autorization', JSON.stringify(obj)); localStorage.setItem('session', 'ok') }
         })
      }
      connect_networks.end()
      ipcRenderer.send('reload_login', { massage: 'reload' })
   })
}

module.exports.connect_to_location = function (log, password) {
   const connect_location = require("./connect_my_location")
   console.log(log)
   let data = [log, password]
   connect_location.query(`SHOW TABLES`, function (err, results) {
      if (err) { console.log(err) }
      else {
         let arr = []
         results.forEach(tab => { arr.push(tab.Tables_in_drag_20_network) })
         localStorage.setItem('all_tables', JSON.stringify(arr))
      }
   })

   connect_location.query(`SELECT * FROM all_users WHERE login=? AND pass=?`, data, (err, results) => {
      if (err) { console.log(err) }
      else {
         localStorage.setItem('session_user', JSON.stringify(results[0]))
         localStorage.setItem('session', 'true')
         localStorage.setItem('session_login', 'true')
         localStorage.setItem('link', 'main_admin_home.html')
         connect_location.end()
         ipcRenderer.send('reload', { massage: 'reload' })
         ipcRenderer.send('reload_login', { massage: 'reload' })
      }
   })
}

module.exports.get_data_location_db = function () {
   const connect_location = require("./connect_my_location")
   let id = get_user_location().id_location
   connect_location.query(`SELECT * FROM locations WHERE id_location=${id}`, function (err_location, results_location) {
      if (err_location) console.log(err_location)
      else { localStorage.setItem('data_location', JSON.stringify(results_location[0])) }
   })
}




module.exports.save_data_location = function (data) {

/*    let sql = `INSERT INTO locations (id_network, name_location, name_network, adres_location, logo_network, work_day_start, work_day_stop, services_location, grodation_masters) VALUES ?`

   let arr_json = []

   data.forEach(element => { 
      if((typeof element) == 'object') { arr_json.push(JSON.stringify(element))}
      else { arr_json.push(element) }
   })
   console.log(arr_json)
   const connect_location = require("./connect_my_location")
   connect_location.query(sql, { arr_json }, function(err, results){ if(err) { console.log(err) } else{ console.log(results) } connect_location.end()})
 */
}
/* function createTable(){
   let sql = `CREATE TABLE locations (
      id_location INT AUTO_INCREMENT PRIMARY KEY,
      id_network INT,
      name_location VARCHAR(255) UNIQUE,
      name_network VARCHAR(255),
      adres_location VARCHAR(255),
      logo_network VARCHAR(255),
      work_day_start TIME,
      work_day_stop TIME,
      services_location TEXT,
      grodation_masters TEXT)`

      const connect_location = require("./connect_my_location")
      connect_location.query(sql, function(err, results){ if(err) console.log(err);    connect_location.end()})
} */