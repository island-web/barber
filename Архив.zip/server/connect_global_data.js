const mysql = require('mysql2')
const { global_host, global_user, global_database, global_password } = require('../front/global_values')

let connect_networks = mysql.createConnection({ host: global_host(), user: global_user(), database: global_database(), password: global_password() })
connect_networks.connect(function(err) { if(err) { throw err } else { console.log('connect to connect_networks - ok') }})

module.exports = connect_networks