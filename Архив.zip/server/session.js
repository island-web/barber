//
const si = require('systeminformation')
const data_time = require('date-and-time')


module.exports.start = function(login){


}

module.exports.session_status = function(){ return localStorage.getItem('session_status_pin') }