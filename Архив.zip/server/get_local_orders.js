const connect = require("./connect_my_location")

let id_loc = JSON.parse(localStorage.getItem('data_location'))
id_loc = id_loc.id_location
module.exports.local_orders_db = function () {
    connect.connect()

    connect.query(`SELECT * FROM all_orders WHERE id_location=${id_loc} AND date_order>=${day_time.format(new Date(), 'DD-MM-YYYY')}`,
        function (err, results) {
            if (err) console.log(err)
            else { localStorage.setItem('all_orders', JSON.stringify(results)) }
        }
    )
}
