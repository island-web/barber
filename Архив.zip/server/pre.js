module.exports.check_start_data = (() => { return localStorage.getItem('session')})

module.exports.session_login = (() => { return localStorage.getItem('session_login')})


module.exports.session_ready = (() => { return localStorage.getItem('session_ready')})
