const mysql = require('mysql2')

let data = JSON.parse(localStorage.getItem('data_autorization'))
let connect_location = mysql.createConnection({ host: data.host, user: data.user_data_base, database: data.data_base, password: data.password_data_base })
connect_location.connect(function(err) { if(err) { throw err } else { console.log('connect ok local db') }})

module.exports = connect_location