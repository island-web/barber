$('#network_name').html(`<img src="${logo_network}"/> `);
$('#name_user_bar').html(`${user('name')}`);
$('#status_user_bar').html(`${user('status')}`);

