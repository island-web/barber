///работа с масивом данных user


$('#last_enter').html(`Останній візит: ${user('last_login')}`);
$('#img_user').attr('src' , user('img_master'));
$('#name_user').html(user('name'));

$(function(){
	$(".alert-info-up-panel").delay(5000).slideUp(300);
});


