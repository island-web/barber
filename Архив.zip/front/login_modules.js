const { check_start_data } = require("./server/pre")


//$(document).keyup(function (e) { if (e.keyCode == 13) { data_base.check_network($('#init-val').val()) }})

$('#init-btn').click(function () { data_base.check_network($('#init-val').val()) })

if(check_start_data() == 'ok'){ global_modul.hide_block('login-box-1'); global_modul.show_block('login-box-2') }
   
$('#mail_pass_btn').click(function () { data_base.connect_to_location($('#email_inp').val(), $('#password_inp').val()) })

