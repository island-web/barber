
const { webContents } = require('electron')
const values = require('./front/global_values')

$('.add-master-save-btn').click(function () {

})
let data_location = values.get_data_location()
console.log(data_location)
// data_location.service_location.forEach(element => {
//    $('#checkboxes').append(`
//    <div class='checkbox-unit'><label for='${element}'><input name='service_${element}'
//    class='checkboxes-input' type='checkbox' id='${element}'/>${element}</option>
// <p>
//    <input class='edit-data-master-input edit-data-master-input-click'
//        id='price_${element}' name='price_${element}' type='number'
//        placeholder='ціна послуги' value='' require />
//    <input class='edit-data-master-input mar-left' id='time_${element}'
//        name='time_${element}' type='number' placeholder='час послуги'
//        value='' require />
// </p>
// </div>
//    `)
// });
// ////////////////////////
// data_location.status_user_location.forEach(status => {
//    $('.checkboxes-status').append(`
//       <label for='${status}'>
//       <input name='status' class='checkboxes-input' type='checkbox' id='${status}' />${status}</option>
//       `)
// });