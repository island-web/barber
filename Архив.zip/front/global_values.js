module.exports.global_host = (() => { return '89.184.68.183' })
module.exports.global_user = (() => { return 'u_all_brb_ne' })
module.exports.global_database = (() => { return 'all_brb_networks' })
module.exports.global_password = (() => { return 'lhpN3C53' })


module.exports.get_user_location=(()=>{return JSON.parse(localStorage.getItem('session_user'))})
module.exports.get_link = (() => { return localStorage.getItem('link') })
module.exports.pin_status = (() => { return localStorage.getItem('session_status_pin') })
module.exports.get_my_location = (() => { return JSON.parse(localStorage.getItem('my_location')) })
/*&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
module.exports.get_tables = (() => { return localStorage.getItem('all_tables') })
/*&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
module.exports.get_data_location=(()=>{
    let data = JSON.parse(localStorage.getItem('data_location'), 'utf-8')
    data.services_location = JSON.parse(data.services_location)
    data.grodation_masters = JSON.parse(data.grodation_masters)
    return data
})




module.exports.get_local_data = ((name) => { return localStorage.getItem(name) })
module.exports.set_local_data = ((name, data) => { localStorage.setItem(name, data) })