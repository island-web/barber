

module.exports.global_host = (() => { return '89.184.68.183' })
module.exports.global_user = (() => { return 'u_all_brb_ne' })
module.exports.global_database = (() => { return 'all_brb_networks' })
module.exports.global_password = (() => { return 'lhpN3C53' })

module.exports.now_day = (() => { return day_time.format(new Date(), 'DD-MM-YYYY') })
module.exports.now_time = (() => { return day_time.format(new Date(), 'HH:mm:ss') })
module.exports.now_time_h_m = (() => { return day_time.format(new Date(), 'HH:mm') })


module.exports.get_user_location = (() => { return JSON.parse(localStorage.getItem('session_user'), 'utf8mb4_croatian_ci') })
module.exports.get_link = (() => { return localStorage.getItem('link') })
module.exports.pin_status = (() => { return localStorage.getItem('session_status_pin') })
module.exports.get_my_location = (() => { return JSON.parse(localStorage.getItem('my_location')) })
/*&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
module.exports.get_tables = (() => { return localStorage.getItem('all_tables') })
/*&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
module.exports.get_data_location = (() => {
    let data = JSON.parse(localStorage.getItem('data_location'), 'utf-8')
    data.services_location = JSON.parse(data.services_location)
    data.grodation_masters = JSON.parse(data.grodation_masters)
    return data
})

module.exports.get_all_users = (() => {

    let data = JSON.parse(localStorage.getItem('all_users_location'), 'utf-8')
    let all_users = new Array()
    data.forEach(element => {
        let temp_arr = new Object()
        for (key in element) {
            try {
                temp_arr[key] = JSON.parse(element[key])
            } catch (e) {
                temp_arr[key] = element[key]
            }
        }
        all_users.push(temp_arr)
    })
    return all_users

})

module.exports.get_all_orders = (() => { 
    let temp_orders = JSON.parse(localStorage.getItem('all_orders')) 
    let output_arr = []
    for(key in temp_orders){
        let temp_arr = []
        for(k in temp_orders[key]){
            try{
                temp_arr[k]=JSON.parse(temp_orders[key][k])
                }catch(e){
                    temp_arr[k]=temp_orders[key][k]
                }        
        }
        output_arr.push(temp_arr)
    }
    console.log(output_arr)
    return output_arr
})



module.exports.get_local_data = ((name) => { return localStorage.getItem(name) })
module.exports.set_local_data = ((name, data) => { localStorage.setItem(name, data) })