   //const { shell } = require("systeminformation")

const { get_link, now_time, get_all_users } = require("./global_values")


module.exports.hide_block = function (class_name) {
   $(`.${class_name}`).hide()
}
module.exports.show_block = function (class_name) {
   $(`.${class_name}`).show()
}
module.exports.insert_header = function () {
   let header = fs.readFileSync('./templates_html/header.html', { encoding: 'utf8', flag: 'r' });
   $('.header-parent').html(header)
}
module.exports.insert_sitebar = function () {
   let site_bar = fs.readFileSync('./templates_html/nav_bar.html', { encoding: 'utf8', flag: 'r' });
   $('.nav-parent').html(site_bar)
}
module.exports.insert_footer = function () {
   let footer = fs.readFileSync('./templates_html/footer.html', { encoding: 'utf8', flag: 'r' });
   $('.footer-parent').html(footer)
}
module.exports.insert_content = function (link) {
   let content = fs.readFileSync(`./templates_html/${link}`, { encoding: 'utf8', flag: 'r' });
   $('.main-parent').html(content)
}
module.exports.rout = function () {
   $('.nav-bar-click').click(function () {
      localStorage.setItem('link', this.id)
      ipcRenderer.send('reload', { message: 'reload' })
   })
}
module.exports.visual = function () {
   global_modul.insert_header()
   global_modul.insert_sitebar()
   global_modul.insert_footer()

   let link = (get_link() == null) ? 'main_admin_home.html' : get_link()

   global_modul.insert_content(link)
}
module.exports.list_masters_day = function (day) {
   
   all_masters.forEach(master => {
      let work = []
      for (key in master) {
         if (key == 'work_day') {
            work = master[key]
            for (work_day in work) {
               if (work_day == day) {
                  $('.data_barber_work_today').append(`
                  <div class="click-data-barber">
                     <ul class="all_barbers_work_today" style="display:flex;">
                        <li class="li-name" name="name"><img id="${master.img_user}" class="home-admin-masters-img" src="${master.img_user}" alt="">${master.name_user}</li>
                        <li  name="work_time">${work[work_day].start_work_day} - ${work[work_day].stop_work_day}</li>
                        <li class="adaptive-li-normal"><button id='${master.id_user}' value='${master.name_user}' class="show_orders">Дивитись</button></li>
                        <li class="adaptive-li-normal"><form method='post'><button id='${master.id_user}' value='${master.id_user}' name="add_order" >Додати</button></form></li>
                        <li class="adaptive-li-normal">
                        <form method="POST">
                           <input type="hidden" name="id_master" value="${master.id_user}"></input>
                           <input type="hidden" name="close_day" value="${day}"></input>
                           <input type="hidden" name="close_time" value="${now_time()}"></input>    
                           <input  class="end-work-click" type="submit" id="${master.id_user}" name="end_work" value="Закрити"/>
                           </form>
                        </li>
                        <li class="edit-admin-btn">Деталі</li>
                     </ul>
      
                     <div class="edit-admin-window">
                     <li><button class="show_orders" value='${master.name_user}' id='${master.id_user}'>Дивитись замовлення</button></li>
                     <li><form method='post'><button type="submit" value='ok' name="add_order" >Додати замовлення</button></form></li>
                     <li>
                     <form method="POST">
                        <input type="hidden" name="id_master" value="${master.id_user}"></input>
                        <input type="hidden" name="close_day" value="${day}"></input>
                        <input type="hidden" name="close_time" value="${now_time()}"></input>
                        <input  class="end-work-click" type="submit" id="${master.id_user}" name="end_work" value="Закрити зміну"/></li>
                     </form>
                  </div>
                  </div>`)
               }
            }
         }
      }
   })
}