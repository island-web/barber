//const { shell } = require("systeminformation")

const { get_link } = require("./global_values")

module.exports.hide_block = function (class_name) {
   $(`.${class_name}`).hide()
}
module.exports.show_block = function (class_name) {
   $(`.${class_name}`).show()
}
module.exports.insert_header = function () {
   let header = fs.readFileSync('./templates_html/header.html', { encoding: 'utf8', flag: 'r' });
   $('.header-parent').html(header)
}
module.exports.insert_sitebar = function () {
   let site_bar = fs.readFileSync('./templates_html/nav_bar.html', { encoding: 'utf8', flag: 'r' });
   $('.nav-parent').html(site_bar)
}
module.exports.insert_footer = function () {
   let footer = fs.readFileSync('./templates_html/footer.html', { encoding: 'utf8', flag: 'r' });
   $('.footer-parent').html(footer)
}
module.exports.insert_content = function (link) {
   let content = fs.readFileSync(`./templates_html/${link}`, { encoding: 'utf8', flag: 'r' });
   $('.main-parent').html(content)
}
module.exports.rout = function () {
   $('.nav-bar-click').click(function () {
      localStorage.setItem('link', this.id)
      ipcRenderer.send('reload', { message: 'reload' })
   })
}
module.exports.visual = function () {
   global_modul.insert_header()
   global_modul.insert_sitebar()
   global_modul.insert_footer()

   let link = (get_link() == null) ? 'main_admin_home.html' : get_link()
   console.log(link)

   global_modul.insert_content(link)
}


/* module.exports.modal_error = function(message){
   $('#modal-error-message').text(message)
   $('#modal-error-close').click(function () {
      ipcRenderer.send('modal_error_close', { massage: 'modal_error_close' })
   })
} */