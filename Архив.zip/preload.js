const { ipcRenderer } = require("electron");
const { check_start_data, session_ready, session_login } = require("./server/pre")



if(session_ready() != 'true'){

    if (check_start_data() != 'true') { 
        if (check_start_data() != 'ok') { ipcRenderer.send('login', { massage: 'start login' }) }
    }
    
    else if(session_login() == 'true'){

        localStorage.setItem('session_ready', 'true')
        setTimeout(()=> {ipcRenderer.send('reload', { message: 'reload' })},1000) 
    
    }
}



