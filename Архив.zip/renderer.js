//********************************************************************************************* */
//ELECTRON MODULES
const { ipcRenderer } = require("electron");
const $ = require('jquery')
const shell = require('shelljs')
const fs = require('fs');
const kill = require('kill-process-by-name')



//********************************************************************************************* */

//MY MODULES
const session = require('./server/session')
const home_modules = require('./front/home')
//const login_modules = require('./front/login_modules')
const data_base = require('./server/data_base')
const global_modul = require('./front/global_modules')
const local_values = require('./front/global_values')
const event_message = require('./front/message');
const { session_ready } = require("./server/pre");
const { sendvich } = require("./js/main");

//********************************************************************************************* */
window.addEventListener('DOMContentLoaded', () => {
   if (session_ready() == 'true') {
      data_base.get_data_location_db()
      ipcRenderer.send('close_login', { message: 'close_login' })
      global_modul.visual()
      global_modul.rout()
      sendvich()
   }

})
















//********************************************************************************************* */


/* if (session.session_status() == null) { ipcRenderer.send('login', { massage: 'start login' }); login_modules.click_login_id() }
else if (session.session_status() == 'ok') { login_modules.login_box_2_show(); login_modules.check_mail_pass() }
else if (session.session_status() == 'work') {
   global_modul.gamno_visual()
   global_modul.rout()
   global_modul.gamno_log_out()
   data_base.get_data_location()
}
 */

//********************************************************************************************* */
